#!/bin/bash
IP_RAW=$(ifconfig eth0 | grep inet -m 1)
read -ra ADDR <<< "$IP_RAW"
for ((i=0; i<2; i++))
do
    if [ $i == 1 ]; then
        IP="${ADDR[$i]}"
    fi
done

echo $IP
