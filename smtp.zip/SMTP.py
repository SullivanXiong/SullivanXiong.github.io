from_address = "sxiong5307@gmail.com"
to_address = "sxiong5307@gmail.com"
subject = "raspberry pi IP"
username = "sxiong5307"
password = "gaffylwlllpmacor"

def send_email(ip):
    print("Initializing mail body...")
    time.sleep(3)
    body_text = ip + " is our Raspberry Pi IP address"
    msg = "\r\n".join(['To: %s' % to_address,
                        'From: %s' % from_address,
                        'Subject: %s' % subject,
                        '', body_text])
    print("Connecting to smtp.gmail.com:587...")
    time.sleep(2)
    server = smtplib.SMTP('smtp.gmail.com', '587')
    server.starttls()
    server.login(username, password)
    print("Logged in as %s..." % username)
    server.sendmail(from_address, to_address, msg)
    server.quit()
    print("Email has been sent!")

