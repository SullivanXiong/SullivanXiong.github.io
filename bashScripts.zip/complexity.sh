complexity -t0 -s1 *.c | grep ".c(" > complexityScores.txt

NUMFUNCS="$(cat complexityScores.txt | grep -c *.c)"

while read num rest
do
   echo $num
done < complexityScores.txt > scores.txt


# Total Complexity
# sum of all complexity score
SUM=0

while read line
do
   SUM=$(( $SUM + $line ))
done < scores.txt

echo -e "Total Complexity:    $SUM"

# Maximum Complexity
# biggest complexity score
MAX=$( tail -n 1 scores.txt )

echo -e "Maximum Complexity:  $MAX"

# Average Complexity
# average complexity score
AVG="$( bc <<<"scale=2; $SUM / $NUMFUNCS" )"


echo -e "Average Complexity:  $AVG"

# Ratio
# top quartile / sum of complexities
TOPQUARTILE="$( bc <<<"scale=4; $NUMFUNCS / 4" )"
echo "Top-quartile number of functions: $TOPQUARTILE"

TOTAL=0
COUNT=1

while [ $( $TOPQUARTILE>0 | bc ) ]
do
   CURR=$( tail -n $COUNT scores.txt )
   if [ $TOPQUARTILE -gt 1 ]
      then
         TOPQUARTILE=$(( $TOPQUARTILE - 1 ))
         COUNT=$(( $COUNT + 1))
      else
         TOTAL=$(( $TOTAL + (( $TOPQUARTILE * $CURR )) ))
   fi
done
RATIO=$(   )

echo "should be 0.3428"
echo -e "Ratio Complexity:    $RATIO"
