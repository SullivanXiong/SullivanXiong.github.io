#!//bin/bash

PWD="$(pwd | sed 's/\/\/home\/suxiong\/asgn\/cpe357\///g')"
INIT="$(ls | grep -c requirements)"
CFILECOUNT="$(ls | grep -c *.c)"
NUMTEST="$(ls | grep -c *.in)"
TESTCASES=0

# Get Requirements file
cp ~kmammen-grader/evaluations/W20/357/$PWD/requirements ./
#cp ~kmammen-grader/evaluations/W20/357/$PWD/tests/core/value ./
#cp ~kmammen-grader/evaluations/W20/357/$PWD/tests/feature/test01/value ./

# Get the Makefile
cp ~kmammen-grader/evaluations/W20/357/$PWD/Makefile ./

# Generate Tests
if [ $TESTCASES -eq 1 ]
   then
      ./generateTests.sh
fi

if [ -z $INIT ]
   then
      exit
fi

###############################################################################

###############################################################################
#
# Style checking the c files.
#
if [ $CFILECOUNT -eq 0 ]
   then
      echo -e "No *.c file found."
      echo -e "Make some .c file(s) before you continue."
      exit
   else
      # Style check
      ~kmammen-grader/bin/styleCheckC *.c
fi

make

###############################################################################

###############################################################################
#
# Creating output files using input.
#
COUNT=0

if [ $NUMTEST -gt 0 ]
   then
      while [ $COUNT -lt $NUMTEST ]
      do
         COUNT=$(( $COUNT + 1 ))
         ./a.out < test$COUNT.in > my$COUNT.out
         ~kmammen/357/Exercise7/dataTyper < test$COUNT.in > actual$COUNT.out
          diff my$COUNT.out actual$COUNT.out > err$COUNT.txt
      done
   else
      ###################################
      #
      # Custom test cases
      #
      ###################################
      #Test1
      ./a.out > my1.out
      ~kmammen/357/Exercise7/dataTyper > actual1.out
      #Test2
      ./a.out s > my2.out
      ~kmammen/357/Exercise7/dataTyper s > actual2.out
      #Test3
      ./a.out 56 > my3.out
      ~kmammen/357/Exercise7/dataTyper 56 > actual3.out
      #Test4
      ./a.out 1.0 > my4.out
      ~kmammen/357/Exercise7/dataTyper 1.0 > actual4.out
      #Test5
      ./a.out hello world > my5.out
      ~kmammen/357/Exercise7/dataTyper hello world > actual5.out
      #Test6
      ./a.out hell.o > my6.out
      ~kmammen/357/Exercise7/dataTyper hell.o > actual6.out
      #Test7
      ./a.out a 420.6969696969 69 hello > my7.out
      ~kmammen/357/Exercise7/dataTyper a 420.6969696969 69 hello > actual7.out
      #Test8
      ./a.out 420.6969696969 a 69 hello > my8.out
      ~kmammen/357/Exercise7/dataTyper 420.6969696969 a 69 hello > actual8.out
      #Test9
      ./a.out 420.6969696969 69 a hello > my9.out
      ~kmammen/357/Exercise7/dataTyper 420.6969696969 69 a hello > actual9.out
      #Test10
      ./a.out 420.6969696969 69 hello a > my10.out
      ~kmammen/357/Exercise7/dataTyper 420.6969696969 69 hello a > actual10.out
      #Test11
      ./a.out hello 420.6969696969 69 a > my11.out
      ~kmammen/357/Exercise7/dataTyper hello 420.6969696969 69 a > actual11.out
      #Test12
      ./a.out 69 420.6969696969 hello a > my12.out
      ~kmammen/357/Exercise7/dataTyper 69 420.6969696969 hello a > actual12.out
      #Test13
      ./a.out 1 hello 2 world 56.0 3 a 4 69.12893173812 5 > my13.out
      ~kmammen/357/Exercise7/dataTyper 1 hello 2 world 56.0 3 a 4 69.12893173812 5 > actual13.out
      COUNT=0
      NUMTEST=13
      while [ $COUNT -lt $NUMTEST ]
      do
         COUNT=$(( $COUNT + 1 ))
         diff my$COUNT.out actual$COUNT.out > err$COUNT.txt
      done
fi

###############################################################################

###############################################################################
#
# Checking err#.txt
#
COUNT=0
ERR=1

while [ $COUNT -lt $NUMTEST ]
do
   COUNT=$(( $COUNT + 1 ))
   if [ -s "err$COUNT.txt" ]
      then
         ERR=0
         echo -e "\n\nYou are not passing all the test cases for actual$COUNT. Keep trying."
         echo -e "diff: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n<"
         cat "my$COUNT.out"
         echo -e "<\n******************************************\n>"
         cat "actual$COUNT.out"
         echo -e ">\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
         exit
      else
         echo -e "\n\nNice work you successfully passed all the test cases for actual$COUNT!"
   fi
done

if [ $ERR -eq 0 ] 
   then
      echo -e "\nYour file is the one in between the '<', and the expected output is the one between the '>'."
      PASSED=0
   else
      echo -e "\nYou've passed all $NUMTEST tests."
      PASSED=1
fi

###############################################################################

if [ $PASSED -eq 1 ]
   then
      ./handin.sh
fi
