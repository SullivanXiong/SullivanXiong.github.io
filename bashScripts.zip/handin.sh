PWD="$(pwd | sed 's/\/\/home\/suxiong\/asgn\/cpe357\///g')"

echo -e "\n\n"
zip $PWD *.c *.h
echo -e "\n\n"
echo -e "Running handin kmammen-grader $PWD-Section9 $PWD.zip\n"
handin kmammen-grader $PWD-Section9 $PWD.zip
echo -e "\n"
unzip -l $PWD.zip

