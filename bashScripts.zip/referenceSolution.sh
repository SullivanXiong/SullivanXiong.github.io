~kmammen/357/Exercise7/dataTyper $@

