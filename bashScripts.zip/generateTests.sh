COUNT=0
DIR="$(pwd | sed 's/\/\/home\/suxiong\/asgn\/cpe357\///g')"

rm *.dsc

while [ 0 -eq 0 ] 
do   
   COUNT=$(( $COUNT + 1))
   if [ $COUNT -lt 10 ]
      then
         cp ~kmammen-grader/evaluations/W20/357/$DIR/tests/core/test0$COUNT/description ./coretest0$COUNT.dsc
         ERR="$(ls | grep -c "coretest0$COUNT.dsc")"
      else
         cp ~kmammen-grader/evaluations/W20/357/$DIR/tests/core/test$COUNT/description ./coretest$COUNT.dsc
         ERR="$(ls | grep -c "coretest$COUNT.dsc")"
   fi
   if [ $ERR -eq 0 ]
      then
         break
   fi
done

CORE=$COUNT
COUNT=0

while [ 0 -eq 0 ] 
do   
   COUNT=$(( $COUNT + 1))
   if [ $COUNT -lt 10 ]
      then
         cp ~kmammen-grader/evaluations/W20/357/$DIR/tests/feature/test0$COUNT/description ./featuretest0$COUNT.dsc
         ERR="$(ls | grep -c "featuretest0$COUNT.dsc")"
      else
         cp ~kmammen-grader/evaluations/W20/357/$DIR/tests/feature/test$COUNT/description ./featuretest$COUNT.dsc
         ERR="$(ls | grep -c "featuretest$COUNT.dsc")"
   fi
   if [ $ERR -eq 0 ]
      then
         break
   fi
done

FEATURE=$COUNT
NUMTEST=$(( $FEATURE + $CORE ))
COUNT=0

EXIST="$(ls | grep -c *.in)"

if [ $EXIST -lt 1 ]
   then
      while [ $COUNT -lt $NUMTEST ]
      do
         COUNT=$(( $COUNT + 1))
         touch test$COUNT.in
      done
fi

clear
