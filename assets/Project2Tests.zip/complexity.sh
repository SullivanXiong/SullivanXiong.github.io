complexity -t0 -s1 *.c | grep ".c(" > complexityScores.txt

NUMFUNCS="$(cat complexityScores.txt | grep -c *.c)"

while read num rest
do
   echo $num
done < complexityScores.txt > scores.txt

complexity -t0 -s1 *.c
echo ""

python3 complexity.py scores.txt
python3 complexity.py scores.txt > c_scores.txt

echo "------------------------------------------ MAMMEN'S REQUIRED COMPLEXITY ------------------------------------------"
echo ""
echo "Total complexity:                               215 (required to be less than 250 to be accepted for grading)"
echo "Maximum complexity:                             41 (required to be less than 48 to be accepted for grading)"
echo "Average complexity:                             16"
echo "Ratio (complexity of top-quartile to total):    0.55"
