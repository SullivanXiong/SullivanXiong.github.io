import sys


def parse_to_int(lst):
   new_lst = []
   for i, j in enumerate(lst):
      if j != "\n":
         new_lst.append(int(j))
   return new_lst

def sum_scores(lst):
   _sum = 0
   for i, j in enumerate(lst):
     _sum+=j
   return _sum

def average_scores(_sum, _len):
   return _sum / _len

def ratio_scores(lst, _sum):
   top_quartile = len(lst)/4
   sum_quartile = 0
   count = 0

   while (top_quartile > 0):
      if top_quartile >= 1:
         top_quartile-=1
         count+=1
         sum_quartile += lst[len(lst)-count]
      else:
         count +=1
         sum_quartile += (lst[len(lst)-count] * top_quartile)
         top_quartile = 0

   return sum_quartile / _sum
         

if __name__ == "__main__":
   scores = sys.argv[1]
   with open(scores, "r") as f:
      list_scores = f.readlines()
      list_scores = parse_to_int(list_scores)
      
      sum = sum_scores(list_scores)
      maximum = list_scores[len(list_scores)-1]
      average = average_scores(sum, len(list_scores))
      ratio = ratio_scores(list_scores, sum)

      print()
      print("Total program complexity:     %.4f"%sum)
      print("Maximum program complexity:   %.4f"%maximum)
      print("Average program complexity:   %.4f"%average)
      print("Ratio program complexity:     %.4f"%ratio)
      print()
 
