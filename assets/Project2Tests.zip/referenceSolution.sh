~kmammen/357/Project2/swc $@

