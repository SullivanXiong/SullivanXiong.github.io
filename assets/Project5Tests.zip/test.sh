make
echo ""
~kmammen-grader/bin/styleCheckC *.c
echo ""
mkdir output
echo "--------------------------------------------------------"
echo ""

#################################################
#
# Test 1
#

./a.out ~kmammen/357/Project5/wildChild -p 2 < ./tests/*.core1 1> output/myCore1.out 2> output/myCore1.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 2 < ./tests/*.core1 1> output/actCore1.out 2> output/actCore1.err
echo "coretest1: For coretest1 "
diff -q output/myCore1.out output/actCore1.out
diff -q output/myCore1.err output/actCore1.err
echo ""

#
#
#################################################

##################################################
#
# Test 2
#

./a.out ~kmammen/357/Project5/wildChild -p 2 < ./tests/*.core2 1> output/myCore2.out 2> output/myCore2.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 2 < ./tests/*.core2 1> output/actCore2.out 2> output/actCore2.err
echo "coretest2: For coretest2 "
diff -q output/myCore2.out output/actCore2.out
diff -q output/myCore2.err output/actCore2.err
echo ""

#
#
#################################################

##################################################
#
# Test 3
#

./a.out ~kmammen/357/Project5/wildChild -p 7 < ./tests/*.core3 1> output/myCore3.out 2> output/myCore3.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 7 < ./tests/*.core3 1> output/actCore3.out 2> output/actCore3.err
echo "coretest3: For coretest3 "
diff -q output/myCore3.out output/actCore3.out
diff -q output/myCore3.err output/actCore3.err
echo ""

#
#
#################################################

##################################################
#
# Test 4
#

./a.out ~kmammen/357/Project5/wildChild -p 10 < ./tests/*.core4 1> output/myCore4.out 2> output/myCore4.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 10 < ./tests/*.core4 1> output/actCore4.out 2> output/actCore4.err
echo "coretest4: For coretest4 "
diff -q output/myCore4.out output/actCore4.out
diff -q output/myCore4.err output/actCore4.err
echo ""

#
#
#################################################

##################################################
#
# Test 5
#

./a.out ~kmammen/357/Project5/wildChild -p 10 < ./tests/*.core5 1> output/myCore5.out 2> output/myCore5.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 10 < ./tests/*.core5 1> output/actCore5.out 2> output/actCore5.err
echo "coretest5: For coretest5 "
diff -q output/myCore5.out output/actCore5.out
diff -q output/myCore5.err output/actCore5.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 1
#

./a.out ~kmammen/357/Project5/wildChild -p 3 < ./tests/*.feat1 1> output/myFeat1.out 2> output/myFeat1.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 3 < ./tests/*.feat1 1> output/actFeat1.out 2> output/actFeat1.err
echo "feattest1: For feattest1 "
diff -q output/myFeat1.out output/actFeat1.out
diff -q output/myFeat1.err output/actFeat1.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 2
#

./a.out ~kmammen/357/Project5/wildChild -p 4 < ./tests/*.feat2 1> output/myFeat2.out 2> output/myFeat2.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 4 < ./tests/*.feat2 1> output/actFeat2.out 2> output/actFeat2.err
echo "feattest2: For feattest2 "
diff -q output/myFeat2.out output/actFeat2.out
diff -q output/myFeat2.err output/actFeat2.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 3
#

./a.out ~kmammen/357/Project5/wildChild -p 5 < ./tests/*.feat3 1> output/myFeat3.out 2> output/myFeat3.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 5 < ./tests/*.feat3 1> output/actFeat3.out 2> output/actFeat3.err
echo "feattest3: For feattest3 "
diff -q output/myFeat3.out output/actFeat3.out
diff -q output/myFeat3.err output/actFeat3.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 4
#

./a.out ~kmammen/357/Project5/wildChild -p 6 < ./tests/*.feat4 1> output/myFeat4.out 2> output/myFeat4.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 6 < ./tests/*.feat4 1> output/actFeat4.out 2> output/actFeat4.err
echo "feattest4: For feattest4 "
diff -q output/myFeat4.out output/actFeat4.out
diff -q output/myFeat4.err output/actFeat4.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 5
#

./a.out ~kmammen/357/Project5/wildChild -p 7 < ./tests/*.feat5 1> output/myFeat5.out 2> output/myFeat5.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 7 < ./tests/*.feat5 1> output/actFeat5.out 2> output/actFeat5.err
echo "feattest5: For feattest5 "
diff -q output/myFeat5.out output/actFeat5.out
diff -q output/myFeat5.err output/actFeat5.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 6
#

./a.out ~kmammen/357/Project5/wildChild -p 8 < ./tests/*.feat6 1> output/myFeat6.out 2> output/myFeat6.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 8 < ./tests/*.feat6 1> output/actFeat6.out 2> output/actFeat6.err
echo "feattest6: For feattest6 "
diff -q output/myFeat6.out output/actFeat6.out
diff -q output/myFeat6.err output/actFeat6.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 7
#

./a.out ~kmammen/357/Project5/wildChild -p 9 < ./tests/*.feat7 1> output/myFeat7.out 2> output/myFeat7.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 9 < ./tests/*.feat7 1> output/actFeat7.out 2> output/actFeat7.err
echo "feattest7: For feattest7 "
diff -q output/myFeat7.out output/actFeat7.out
diff -q output/myFeat7.err output/actFeat7.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 8
#

./a.out ~kmammen/357/Project5/wildChild -p 8 < ./tests/*.feat8 | head -7 1> output/myFeat8.out 2> output/myFeat8.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 8 < ./tests/*.feat8 | head -7 1> output/actFeat8.out 2> output/actFeat8.err
echo "feattest8: For feattest8 "
diff -q output/myFeat8.out output/actFeat8.out
diff -q output/myFeat8.err output/actFeat8.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 9
#

./a.out -p ~kmammen/357/Project5/wildChild 2 < ./tests/*.feat9 1> output/myFeat9.out 2> output/myFeat9.err
~kmammen/357/Project5/pipeline -p ~kmammen/357/Project5/wildChild 2 < ./tests/*.feat9 1> output/actFeat9.out 2> output/actFeat9.err
echo "feattest9: For feattest9 "
diff -q output/myFeat9.out output/actFeat9.out
diff -q output/myFeat9.err output/actFeat9.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 10
#

./a.out ~kmammen/357/Project5/wildChild -l 2 < ./tests/*.feat10 1> output/myFeat10.out 2> output/myFeat10.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -l 2 < ./tests/*.feat10 1> output/actFeat10.out 2> output/actFeat10.err
echo "feattest10: For feattest10 "
diff -q output/myFeat10.out output/actFeat10.out
diff -q output/myFeat10.err output/actFeat10.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 11
#

./a.out ~kmammen/357/Project5/wildChild 2 < ./tests/*.feat11 1> output/myFeat11.out 2> output/myFeat11.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild 2 < ./tests/*.feat11 1> output/actFeat11.out 2> output/actFeat11.err
echo "feattest11: For feattest11 "
diff -q output/myFeat11.out output/actFeat11.out
diff -q output/myFeat11.err output/actFeat11.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 12
#

./a.out ~kmammen/357/Project5/wildChild -l -p 2 < ./tests/*.feat12 1> output/myFeat12.out 2> output/myFeat12.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -l -p 2 < ./tests/*.feat12 1> output/actFeat12.out 2> output/actFeat12.err
echo "feattest12: For feattest12 "
diff -q output/myFeat12.out output/actFeat12.out
diff -q output/myFeat12.err output/actFeat12.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 13
#

./a.out ~kmammen/357/Project5/wildChild -p < ./tests/*.feat13 1> output/myFeat13.out 2> output/myFeat13.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p < ./tests/*.feat13 1> output/actFeat13.out 2> output/actFeat13.err
echo "feattest13: For feattest13 "
diff -q output/myFeat13.out output/actFeat13.out
diff -q output/myFeat13.err output/actFeat13.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 14
#

./a.out ~kmammen/357/Project5/wildChild -p 11 < ./tests/*.feat14 1> output/myFeat14.out 2> output/myFeat14.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 11 < ./tests/*.feat14 1> output/actFeat14.out 2> output/actFeat14.err
echo "feattest14: For feattest14 "
diff -q output/myFeat14.out output/actFeat14.out
diff -q output/myFeat14.err output/actFeat14.err
echo ""

#
#
#################################################

##################################################
#
# Feat Test 15
#

./a.out ~kmammen/357/Project5/wildChild -p 1 < ./tests/*.feat15 1> output/myFeat15.out 2> output/myFeat15.err
~kmammen/357/Project5/pipeline ~kmammen/357/Project5/wildChild -p 1 < ./tests/*.feat15 1> output/actFeat15.out 2> output/actFeat15.err
echo "feattest15: For feattest15 "
diff -q output/myFeat15.out output/actFeat15.out
diff -q output/myFeat15.err output/actFeat15.err
echo ""

#
#
#################################################

bash complexity.sh