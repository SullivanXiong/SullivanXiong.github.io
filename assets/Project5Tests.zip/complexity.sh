complexity -t0 -s1 pipeline.c launcher.c | grep ".c(" > complexityScores.txt

NUMFUNCS="$(cat complexityScores.txt | grep -c *.c )"

while read num rest
do
   echo $num
done < complexityScores.txt > scores.txt

complexity -t0 -s1 pipeline.c launcher.c
echo ""

python3 complexity.py scores.txt
python3 complexity.py scores.txt > c_scores.txt

echo "------------------------------------------ MAMMEN'S REQUIRED COMPLEXITY ------------------------------------------"
echo ""
echo -n "Total complexity:                               "
echo "130 (required to be less than 150 to be accepted for grading)"
echo -n "Maximum complexity:                             "
echo "25 (required to be less than 30 to be accepted for grading)"
echo -n "Average complexity:                             "
echo "15"
echo -n "Ratio (complexity of top-quartile to total):    "
echo "0.55"
